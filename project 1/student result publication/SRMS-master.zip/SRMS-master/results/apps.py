from django.apps import AppConfig


class ResultsConfig(AppConfig):
    name = 'results'
