package com.example.SRM.service;

import com.example.SRM.model.User;

public interface UserService {
    User getUser(String id);
}