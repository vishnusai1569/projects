package com.example.SRM.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SRM.model.Student;
import com.example.SRM.service.StudentService;

@RestController
public class StudentController {
    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/students")
    public List<Student> getAllStudents(){
        return this.studentService.getStudents();
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/students/{rollNumber}")
    public Student getStudent(@PathVariable String rollNumber){
        return this.studentService.getStudent(Long.parseLong(rollNumber));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/students")
    public Student postStudent(@RequestBody Student student){
        return this.studentService.addStudent(student);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/students")
    public Student putStudent(@RequestBody Student student){
        return this.studentService.updateStudent(student);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/students/{rollNumber}")
    public Student deleteStudent(@PathVariable String rollNumber){
        return this.studentService.deleteStudent(Long.parseLong(rollNumber));
    }
}