package com.example.SRM.dto;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SRM.model.Student;

public interface StudentDao extends JpaRepository<Student, Long> {

}
