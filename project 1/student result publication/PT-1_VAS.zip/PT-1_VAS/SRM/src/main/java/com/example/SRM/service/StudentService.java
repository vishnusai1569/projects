package com.example.SRM.service;

import java.util.List;

import com.example.SRM.model.Student;

public interface StudentService {
    List<Student> getStudents();
    Student getStudent(Long rollNumber);
    Student addStudent(Student student);
    Student updateStudent(Student student);
    Student deleteStudent(Long rollNumber);
}
