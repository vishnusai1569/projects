package com.example.SRM.dto;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SRM.model.User;

public interface UserDao extends JpaRepository<User, String> {

}
