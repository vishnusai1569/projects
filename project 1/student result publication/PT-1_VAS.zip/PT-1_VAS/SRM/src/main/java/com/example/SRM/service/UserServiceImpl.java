package com.example.SRM.service;

import org.springframework.stereotype.Service;

import com.example.SRM.dto.UserDao;
import com.example.SRM.model.User;

@Service
public class UserServiceImpl implements UserService{
    private final UserDao userDao;

    public UserServiceImpl(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public User getUser(String id) {
        return this.userDao.getById(id);
    }
}
